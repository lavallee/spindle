---
name: ambient
description: Unrelated user-managed fixture preserved during native hook validation.
---

This fixture is deliberately foreign to Spindle ownership.
